from gempa import *

banten = Gempa('Banten', 1.2)
palu = Gempa('Palu', 6.1)
cianjur = Gempa('Cianjur', 5.6)
jayapura = Gempa('Jayapura', 3.3)
garut = Gempa('Garut', 4.0)


banten.data_gempa()
palu.data_gempa()
cianjur.data_gempa()
jayapura.data_gempa()
garut.data_gempa()